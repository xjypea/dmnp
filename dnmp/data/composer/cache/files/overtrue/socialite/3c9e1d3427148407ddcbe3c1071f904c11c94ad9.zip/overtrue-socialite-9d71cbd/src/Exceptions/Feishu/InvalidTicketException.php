<?php

namespace Overtrue\Socialite\Exceptions\Feishu;

use Overtrue\Socialite\Exceptions\Exception;

class InvalidTicketException extends Exception
{
}
