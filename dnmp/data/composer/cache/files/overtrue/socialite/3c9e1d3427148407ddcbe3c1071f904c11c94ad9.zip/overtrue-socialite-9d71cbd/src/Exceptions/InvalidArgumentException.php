<?php

namespace Overtrue\Socialite\Exceptions;

class InvalidArgumentException extends Exception
{
    //
}
