<?php

namespace Overtrue\Socialite\Exceptions;

class MethodDoesNotSupportException extends Exception
{
    //
}
