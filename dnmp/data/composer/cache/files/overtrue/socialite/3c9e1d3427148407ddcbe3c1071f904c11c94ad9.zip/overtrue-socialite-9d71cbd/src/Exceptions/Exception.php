<?php

namespace Overtrue\Socialite\Exceptions;

class Exception extends \Exception
{
    //
}
