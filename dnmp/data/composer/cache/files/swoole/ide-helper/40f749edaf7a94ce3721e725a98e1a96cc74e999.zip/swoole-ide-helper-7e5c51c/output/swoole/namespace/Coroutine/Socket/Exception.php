<?php

namespace Swoole\Coroutine\Socket;

class Exception extends \Swoole\Exception
{


}
