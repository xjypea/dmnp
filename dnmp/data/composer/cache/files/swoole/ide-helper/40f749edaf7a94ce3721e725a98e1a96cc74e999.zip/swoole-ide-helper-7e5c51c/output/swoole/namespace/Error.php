<?php

namespace Swoole;

class Error extends \Error
{


}
