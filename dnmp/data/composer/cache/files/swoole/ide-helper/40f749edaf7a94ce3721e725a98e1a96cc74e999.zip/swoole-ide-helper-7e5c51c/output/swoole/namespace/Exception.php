<?php

namespace Swoole;

class Exception extends \Exception
{


}
