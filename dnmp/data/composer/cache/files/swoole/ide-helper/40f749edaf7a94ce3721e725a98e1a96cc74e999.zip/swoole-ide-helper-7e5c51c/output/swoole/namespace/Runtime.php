<?php

namespace Swoole;

class Runtime
{

    /**
     * @return mixed
     */
    public static function enableCoroutine($enable = null, $flags = null)
    {
    }

    /**
     * @return mixed
     */
    public static function getHookFlags()
    {
    }

    /**
     * @return mixed
     */
    public static function setHookFlags($flags)
    {
    }


}
