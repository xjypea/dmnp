<?php

declare(strict_types=1);

namespace Swoole;

class Exception extends \Exception
{
}
