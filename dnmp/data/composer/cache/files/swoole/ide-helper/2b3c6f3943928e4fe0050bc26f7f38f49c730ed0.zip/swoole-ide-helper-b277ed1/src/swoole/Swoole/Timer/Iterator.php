<?php

declare(strict_types=1);

namespace Swoole\Timer;

/**
 * @see https://www.php.net/ArrayIterator
 */
class Iterator extends \ArrayIterator
{
}
