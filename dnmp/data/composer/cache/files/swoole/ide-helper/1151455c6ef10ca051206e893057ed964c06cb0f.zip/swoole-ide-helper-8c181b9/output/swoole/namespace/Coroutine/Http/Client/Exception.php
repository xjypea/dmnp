<?php

namespace Swoole\Coroutine\Http\Client;

class Exception extends \Swoole\Exception
{


}
