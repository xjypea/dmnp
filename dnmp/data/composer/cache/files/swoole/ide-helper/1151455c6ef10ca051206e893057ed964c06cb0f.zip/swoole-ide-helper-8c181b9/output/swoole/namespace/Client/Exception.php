<?php

namespace Swoole\Client;

class Exception extends \Swoole\Exception
{


}
