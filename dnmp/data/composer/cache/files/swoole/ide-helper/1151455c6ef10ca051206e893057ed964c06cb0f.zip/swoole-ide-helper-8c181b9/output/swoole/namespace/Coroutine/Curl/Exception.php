<?php

namespace Swoole\Coroutine\Curl;

class Exception extends \Swoole\Exception
{


}
