<?php

namespace Swoole\Http;

class Server extends \Swoole\Server
{


}
