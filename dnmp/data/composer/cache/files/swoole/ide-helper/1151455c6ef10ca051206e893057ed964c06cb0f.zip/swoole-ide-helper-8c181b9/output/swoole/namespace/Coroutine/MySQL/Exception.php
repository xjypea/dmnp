<?php

namespace Swoole\Coroutine\MySQL;

class Exception extends \Swoole\Exception
{


}
