<?php

namespace Doctrine\DBAL\Driver\IBMDB2;

use Exception;

class DB2Exception extends Exception
{
}
