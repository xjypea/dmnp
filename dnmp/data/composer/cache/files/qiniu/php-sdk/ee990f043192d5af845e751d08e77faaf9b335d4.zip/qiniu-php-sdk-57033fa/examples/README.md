# examples

这些 examples 旨在帮助你快速了解使用七牛的 SDK。这些 demo 都是可以直接运行的， 但是在运行之前需要填上您自己的参数。

比如：

* `$bucket`  需要填上您想操作的 [bucket名字](https://portal.qiniu.com/kodo/bucket)。
* `$accessKey` 和 `$secretKey` 可以在我们的[管理后台](https://portal.qiniu.com/user/key)找到。
* 在进行`视频转码`， `压缩文件`等异步操作时 需要使用到的队列名称也可以在我们[管理后台](https://portal.qiniu.com/dora/media-gate/pipeline)新建。

