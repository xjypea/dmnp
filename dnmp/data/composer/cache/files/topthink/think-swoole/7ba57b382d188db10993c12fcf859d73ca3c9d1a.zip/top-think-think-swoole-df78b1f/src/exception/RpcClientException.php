<?php

namespace think\swoole\exception;

use Exception;

class RpcClientException extends Exception
{

}
