<?php
phpinfo();
//require_once './vendor/autoload.php';
//$upload = \EasyUpload\EasyUpload::Instance();
//$res = $upload->imgUpload();
//echo json_encode($res,JSON_UNESCAPED_UNICODE);
//echo '<img src="'.$upload->httpPath('./uploads/images/20210621/1a2ab0be8daadb2b336b026db296de39.png').'">';