<?php

namespace Qcloud\Cos\Exception;

class CosException extends ServiceResponseException {}
