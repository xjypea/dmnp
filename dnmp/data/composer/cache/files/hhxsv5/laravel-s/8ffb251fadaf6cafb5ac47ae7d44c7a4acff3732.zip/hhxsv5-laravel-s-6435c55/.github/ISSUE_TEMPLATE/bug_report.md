---
name: Bug report
about: Create a report to help us improve
title: ''
labels: analyzing
assignees: hhxsv5

---

1. Your software version (Screenshot of your startup)
    
    | Software | Version |
    | --------- | --------- |
    | PHP | TODO |
    | Swoole | TODO |
    | Laravel/Lumen | TODO |

2. Detail description about this issue(error/log)

    `TODO`

3. Some `reproducible` code blocks and `steps`

    ```PHP
    // TODO: your code
    ```
