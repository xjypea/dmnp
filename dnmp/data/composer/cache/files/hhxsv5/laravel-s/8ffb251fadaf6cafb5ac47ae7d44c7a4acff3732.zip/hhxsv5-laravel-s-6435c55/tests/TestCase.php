<?php

namespace Hhxsv5\LaravelS\Tests;

class TestCase extends \PHPUnit\Framework\TestCase
{
    
}