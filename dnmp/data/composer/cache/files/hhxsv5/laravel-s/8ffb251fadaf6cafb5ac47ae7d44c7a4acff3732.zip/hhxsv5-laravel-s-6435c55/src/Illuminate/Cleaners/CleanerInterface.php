<?php

namespace Hhxsv5\LaravelS\Illuminate\Cleaners;

interface CleanerInterface
{
    public function clean();
}