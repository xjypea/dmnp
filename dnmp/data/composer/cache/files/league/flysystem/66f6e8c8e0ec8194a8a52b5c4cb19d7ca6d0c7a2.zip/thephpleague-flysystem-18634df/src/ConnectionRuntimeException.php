<?php

namespace League\Flysystem;

use RuntimeException;

class ConnectionRuntimeException extends RuntimeException implements FilesystemException
{
}
