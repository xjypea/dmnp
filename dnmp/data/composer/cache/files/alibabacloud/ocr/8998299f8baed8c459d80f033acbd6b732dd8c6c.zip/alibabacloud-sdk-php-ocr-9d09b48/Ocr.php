<?php

namespace AlibabaCloud\Ocr;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20191230\OcrApiResolver v20191230()
 */
class Ocr extends VersionResolver
{
}
