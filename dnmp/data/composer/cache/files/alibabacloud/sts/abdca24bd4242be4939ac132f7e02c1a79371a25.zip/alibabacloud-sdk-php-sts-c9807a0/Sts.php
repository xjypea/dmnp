<?php

namespace AlibabaCloud\Sts;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @method static V20150401\StsApiResolver v20150401()
 */
class Sts extends VersionResolver
{
}
