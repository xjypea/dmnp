<?php

namespace AlibabaCloud\Sts;

use AlibabaCloud\Client\Resolver\VersionResolver;

/**
 * @deprecated
 */
class StsVersion extends VersionResolver
{
}
