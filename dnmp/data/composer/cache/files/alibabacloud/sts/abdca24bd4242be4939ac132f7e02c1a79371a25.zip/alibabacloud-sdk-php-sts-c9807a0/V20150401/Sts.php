<?php

namespace AlibabaCloud\Sts\V20150401;

use AlibabaCloud\Client\Resolver\ApiResolver;

/**
 * @deprecated
 */
class Sts extends ApiResolver
{
}
